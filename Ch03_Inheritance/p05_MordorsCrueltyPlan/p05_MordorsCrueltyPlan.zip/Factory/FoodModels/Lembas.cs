﻿namespace p05_MordorsCrueltyPlan.Factory.FoodModels
{
    public class Lembas : Food
    {
        public Lembas() : base(3)
        {
        }
    }
}
