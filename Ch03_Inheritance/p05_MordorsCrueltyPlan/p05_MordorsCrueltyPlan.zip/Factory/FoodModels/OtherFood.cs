﻿namespace p05_MordorsCrueltyPlan.Factory.FoodModels
{
    public class OtherFood : Food
    {
        public OtherFood() : base(-1)
        {
        }
    }
}
