﻿namespace p05_MordorsCrueltyPlan.Factory.MoodModels
{
    public class JavaScript : Mood
    {
        public JavaScript() : base("JavaScript")
        {
        }
    }
}