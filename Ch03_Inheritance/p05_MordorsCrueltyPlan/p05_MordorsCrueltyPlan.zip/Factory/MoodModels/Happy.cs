﻿namespace p05_MordorsCrueltyPlan.Factory.MoodModels
{
    public class Happy : Mood
    {
        public Happy() : base("Happy")
        {
        }
    }
}