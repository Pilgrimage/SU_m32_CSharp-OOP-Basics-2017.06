﻿namespace p05_MordorsCrueltyPlan.Factory.MoodModels
{
    public class Sad : Mood
    {
        public Sad() : base("Sad")
        {
        }
    }
}