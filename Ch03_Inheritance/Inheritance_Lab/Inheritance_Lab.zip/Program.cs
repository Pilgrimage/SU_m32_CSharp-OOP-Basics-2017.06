﻿namespace Inheritance_Lab
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
