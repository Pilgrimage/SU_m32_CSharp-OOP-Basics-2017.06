﻿public class StartUp
{
    public static void Main()
    {
        RandomList list = new RandomList();

    }
}
