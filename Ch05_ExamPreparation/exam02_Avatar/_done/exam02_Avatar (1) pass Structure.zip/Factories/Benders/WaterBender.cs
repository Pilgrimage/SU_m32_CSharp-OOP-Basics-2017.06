﻿public class WaterBender : Bender
{
}
