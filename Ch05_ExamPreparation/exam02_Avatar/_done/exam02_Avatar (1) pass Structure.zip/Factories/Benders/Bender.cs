﻿public abstract class Bender
{
}

