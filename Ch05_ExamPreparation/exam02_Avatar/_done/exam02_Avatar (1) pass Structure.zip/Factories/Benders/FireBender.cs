﻿public class FireBender : Bender
{
}
