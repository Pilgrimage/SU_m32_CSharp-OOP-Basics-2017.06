﻿public class EarthBender : Bender
{
}
