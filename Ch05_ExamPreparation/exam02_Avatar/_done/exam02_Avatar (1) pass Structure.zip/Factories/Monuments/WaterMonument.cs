﻿public class WaterMonument : Monument
{
}
