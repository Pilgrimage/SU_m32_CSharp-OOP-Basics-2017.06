﻿public class EarthMonument : Monument
{
}
