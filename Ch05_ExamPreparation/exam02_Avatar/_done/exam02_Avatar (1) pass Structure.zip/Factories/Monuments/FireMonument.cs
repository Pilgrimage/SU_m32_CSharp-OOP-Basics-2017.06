﻿public class FireMonument : Monument
{
}
