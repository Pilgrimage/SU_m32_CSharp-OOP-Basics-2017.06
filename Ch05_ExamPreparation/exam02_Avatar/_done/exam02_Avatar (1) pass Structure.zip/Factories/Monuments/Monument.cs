﻿public abstract class Monument
{
}
