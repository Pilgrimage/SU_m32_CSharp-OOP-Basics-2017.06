﻿public class AirMonument : Monument
{
}
