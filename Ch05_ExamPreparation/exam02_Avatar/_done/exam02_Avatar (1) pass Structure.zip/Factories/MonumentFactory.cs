﻿public class MonumentFactory
{
}

