﻿public abstract class Monument
{
    private string name;

    protected Monument(string name)
    {
        this.name = name;
    }

    public abstract int GetAffinity();
}
