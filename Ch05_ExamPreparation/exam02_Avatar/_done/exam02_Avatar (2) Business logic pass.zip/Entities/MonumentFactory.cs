﻿using System;

public class MonumentFactory
{
    public static Monument GetMonument(string type, string name, int secondaryParameter)
    {
        switch (type)
        {
            case "Air":
                return new AirMonument(name, secondaryParameter);
            case "Water":
                return new WaterMonument(name, secondaryParameter);
            case "Fire":
                return new FireMonument(name, secondaryParameter);
            case "Earth":
                return new EarthMonument(name, secondaryParameter);

            default:
                throw new ArgumentException("There is no such type monument (from bender factory)");
        }
    }

}

