﻿using System.Collections.Generic;
using System.Linq;

public class NationsBuilder
{
    private Dictionary<string, Nation> nations;
    private List<string> wars;

    public NationsBuilder()
    {
        this.nations = new Dictionary<string, Nation>()
        {
            {"Air", new Nation()},
            {"Earth", new Nation()},
            {"Fire", new Nation()},
            {"Water", new Nation()},
        };

        this.wars = new List<string>();
    }


    public void AssignBender(List<string> commParams)
    {
        string benderType = commParams[0];
        string name = commParams[1];
        int power = int.Parse(commParams[2]);
        double secondaryParameter = double.Parse(commParams[3]);
        Bender bender = BenderFactory.GetBender(benderType, name, power, secondaryParameter);
        this.nations[benderType].AddBender(bender);
    }

    public void AssignMonument(List<string> commParams)
    {
        string monumentType = commParams[0];
        string name = commParams[1];
        int affinity = int.Parse(commParams[2]);
        Monument monument = MonumentFactory.GetMonument(monumentType, name, affinity);
        this.nations[monumentType].AddMonument(monument);
   }

    public string GetStatus(string nationsType)
    {
        //TODO: Add some logic here … 
        return "";
    }

    public void IssueWar(string nationsType)
    {
        //TODO: Add some logic here … 
    }

    public string GetWarsRecord()
    {
        //TODO: Add some logic here … 
        return "";
    }

}
