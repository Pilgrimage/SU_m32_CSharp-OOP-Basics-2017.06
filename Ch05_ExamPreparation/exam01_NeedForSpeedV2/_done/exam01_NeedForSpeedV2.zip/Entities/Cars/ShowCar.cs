﻿public class ShowCar : Car
{
}

