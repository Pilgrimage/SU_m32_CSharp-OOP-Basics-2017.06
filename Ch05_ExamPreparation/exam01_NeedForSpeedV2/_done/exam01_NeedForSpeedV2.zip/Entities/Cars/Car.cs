﻿public abstract class Car
{
}
