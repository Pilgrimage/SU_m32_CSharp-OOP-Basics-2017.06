﻿public class CasualRace : Race
{
}

