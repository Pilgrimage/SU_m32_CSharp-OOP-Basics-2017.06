﻿public abstract class Race
{
}
