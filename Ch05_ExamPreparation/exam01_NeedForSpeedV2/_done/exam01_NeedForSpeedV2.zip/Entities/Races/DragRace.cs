﻿public class DragRace : Race
{
}

