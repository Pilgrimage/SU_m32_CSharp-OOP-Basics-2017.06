﻿public class DriftRace : Race
{
}

