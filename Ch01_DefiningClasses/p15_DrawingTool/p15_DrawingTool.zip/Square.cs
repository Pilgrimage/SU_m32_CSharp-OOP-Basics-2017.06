﻿namespace p15_DrawingTool
{
    public class Square : Figure
    {
        public Square(int sideA) : base(sideA)
        {
        }
    }
}
