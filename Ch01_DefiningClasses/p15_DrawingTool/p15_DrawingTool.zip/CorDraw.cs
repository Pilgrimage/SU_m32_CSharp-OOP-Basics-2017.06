﻿namespace p15_DrawingTool
{
    using System;

    public class CorDraw
    {

        public static void Draw(Figure figure)
        {
            figure.Draw();
        }
    }
}
