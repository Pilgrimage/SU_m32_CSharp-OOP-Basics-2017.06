﻿namespace p15_DrawingTool
{
    public class Rectangle : Figure
    {
        public Rectangle(int sideA, int sideB) : base(sideA)
        {
            this.sideB = sideB;
        }
    }
}
